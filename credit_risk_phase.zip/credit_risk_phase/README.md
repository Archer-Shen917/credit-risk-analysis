# 第一阶段：公开消费信贷主表的数据质量与EDA

本仓库用于重现第一阶段统计分析，输入为 Kaggle Home Credit Default Risk 的 `application_train.csv` 和 `HomeCredit_columns_description.csv`。**非汇丰银行内部数据，亦非真实证券融资融券数据**。没有附属表时，不声称完成了多表关联及证券专属特征分析。

## 运行

将两个原始CSV放入本项目目录外的 `data/` 文件夹；不需要上传敏感数据到版本库。

```bash
python -m pip install -r requirements.txt
python src/phase1_analysis.py --data data/application_train.csv --dictionary data/HomeCredit_columns_description.csv --output outputs
python -m pytest -q
python -m black --check src tests
python -m isort --check-only src tests
```

运行会覆盖 `outputs/summary.json`、`outputs/tables/*.csv`、`outputs/figures/*.png`。统计为**全量307,511条主表样本**，不是抽样结果。

## 输出含义

- `field_dictionary.csv`：全部122个字段的英文原始释义、类别、缺失率、处理建议。
- `data_quality_flags.csv`：每个申请ID的若干质量预警标志；只做标记、不擅自删除记录。
- `issue_registry.csv`：异常检查汇总。
- `group_default_rates.csv`：关键特征分组的TARGET=1比例。
- `contract_by_credit_income.csv`：二维交叉分析；小样本格子应慎用。
- `target_numeric_correlations.csv`：单变量相关性，**不代表因果**。
- `summary.json`：基础统计和标记统计。

## 局限及后续扩展

客户历史信用和还款表现数据在六个附属CSV中。本阶段只处理当前申请表；后续必须先对附属表按`SK_ID_CURR`聚合后关联，检查键唯一性、先后时点和未来数据泄漏，并开展标签定义与评分模型验证。`TARGET=1`为给定还款困难标签，不能直接称为某银行已核销坏账率。

### 参考

- https://www.kaggle.com/competitions/home-credit-default-risk/data
- https://www.csrc.gov.cn/csrc/c106256/c1654005/content.shtml
- https://www.csrc.gov.cn/csrc/c106256/c1653849/content.shtml
